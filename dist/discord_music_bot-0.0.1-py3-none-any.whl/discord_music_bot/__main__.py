import asyncio
import yaml


from bot import Bot, Music


async def main():
    print("Creating bot...")
    bot = Bot()
    print("Loading configuration file...")
    with open("config.yaml") as config_file:
        config = yaml.safe_load(config_file)

    async with bot:
        print("Adding music cog...")
        await bot.add_cog(Music(bot))
        print("Starting bot...")
        await bot.start(config["secret_token"])


if __name__ == '__main__':
    # BUG: better exit handling
    asyncio.run(main())
